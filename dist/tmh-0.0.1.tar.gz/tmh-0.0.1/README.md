# TMH Speech
TMH Speech is a library that gives access to open source models for transcription.

## Example usage
'''
from tmh import transcribe_from_audio_path

file_path = "path_to_audio_file"
output = transcribe_from_audio_path(file_path)
print("the output is", output)
'''
